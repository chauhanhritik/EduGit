import Questions from './Questions'

export default function Ques() {
    return (
        <div className='ques'>
            <Questions/>
            <Questions/>
            <Questions/>
            <Questions/>
            <Questions/>
            <Questions/>
            <Questions/>
        </div>
    )
}
